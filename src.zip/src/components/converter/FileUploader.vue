<script setup>
import { ref } from 'vue'

const props = defineProps({
  maxFileSize: {
    type: Number,
    default: 10 * 1024 * 1024 // 10MB
  },
  allowedTypes: {
    type: Array,
    default: () => ['application/pdf']
  },
  isUploading: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['file-uploaded'])
const isDragging = ref(false)
const error = ref('')

const handleDrop = (e) => {
  isDragging.value = false
  const file = e.dataTransfer.files[0]
  validateAndEmit(file)
}

const handleFileSelect = (e) => {
  const file = e.target.files[0]
  validateAndEmit(file)
}

const validateAndEmit = (file) => {
  error.value = ''
  if (!file) return

  if (!props.allowedTypes.includes(file.type)) {
    error.value = 'Only PDF files are allowed.'
    return
  }

  if (file.size > props.maxFileSize) {
    error.value = `File is too large. Maximum size is ${props.maxFileSize / (1024 * 1024)}MB.`
    return
  }

  emit('file-uploaded', file)
}
</script>

<template>
  <div 
    class="uploader-container"
    :class="{ 'dragging': isDragging, 'uploading': isUploading }"
    @dragover.prevent="isDragging = true"
    @dragleave.prevent="isDragging = false"
    @drop.prevent="handleDrop"
  >
    <div class="uploader-content">
      <div class="upload-icon">
        <svg v-if="!isUploading" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M11 16V7.85L8.85 10L7.425 8.575L12 4L16.575 8.575L15.15 10L13 7.85V16H11ZM6 20C5.45 20 4.97917 19.8042 4.5875 19.4125C4.19583 19.0208 4 18.55 4 18V15H6V18H18V15H20V18C20 18.55 19.8042 19.0208 19.4125 19.4125C19.0208 19.8042 18.55 20 18 20H6Z" fill="currentColor"/>
        </svg>
        <div v-else class="upload-spinner"></div>
      </div>
      
      <h3>{{ isUploading ? 'Uploading...' : 'Drag & Drop your PDF here' }}</h3>
      <p v-if="!isUploading">or click to browse your files</p>
      
      <input 
        type="file" 
        id="fileInput" 
        accept=".pdf" 
        @change="handleFileSelect"
        :disabled="isUploading"
        class="hidden-input"
      />
      <label for="fileInput" class="upload-label" v-if="!isUploading">Select File</label>
      
      <p class="file-info" v-if="!error && !isUploading">Max size: 10MB</p>
      <p class="error-text" v-if="error">{{ error }}</p>
    </div>
  </div>
</template>

<style scoped>
.uploader-container {
  border: 2px dashed var(--border-color);
  border-radius: var(--radius-lg);
  padding: 3rem;
  text-align: center;
  background: white;
  transition: var(--transition);
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.uploader-container:hover, .uploader-container.dragging {
  border-color: var(--primary);
  background: var(--primary-light);
}

.uploader-container.uploading {
  cursor: wait;
}

.upload-icon {
  width: 64px;
  height: 64px;
  margin: 0 auto 1.5rem;
  color: var(--primary);
}

.upload-icon svg {
  width: 100%;
  height: 100%;
}

.hidden-input {
  display: none;
}

.upload-label {
  display: inline-block;
  padding: 0.75rem 2rem;
  background: var(--primary);
  color: white;
  border-radius: var(--radius-md);
  font-weight: 600;
  margin-top: 1rem;
  cursor: pointer;
}

.upload-label:hover {
  background: var(--primary-hover);
}

h3 {
  margin-bottom: 0.5rem;
  color: var(--text-main);
}

p {
  color: var(--text-muted);
}

.file-info {
  font-size: 0.75rem;
  margin-top: 1rem;
}

.error-text {
  color: var(--error);
  font-size: 0.875rem;
  margin-top: 1rem;
  font-weight: 600;
}

.upload-spinner {
  width: 48px;
  height: 48px;
  border: 4px solid var(--primary-light);
  border-top-color: var(--primary);
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 8px auto;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
</style>
