<script setup>
import PrimaryButton from '@/components/common/PrimaryButton.vue'

const props = defineProps({
  wordFile: {
    type: [Object, Blob],
    required: true
  },
  fileName: {
    type: String,
    required: true
  },
  fileSize: {
    type: [Number, String],
    required: false
  }
})

const emit = defineEmits(['download', 'reset'])

const getDisplaySize = () => {
  if (props.fileSize) {
    if (typeof props.fileSize === 'number') {
      return formatSize(props.fileSize)
    }
    return props.fileSize
  }
  
  if (props.wordFile) {
    if (props.wordFile.fileSize) {
      return props.wordFile.fileSize
    }
    if (props.wordFile.size) {
      return formatSize(props.wordFile.size)
    }
    if (props.wordFile.blob && props.wordFile.blob.size) {
      return formatSize(props.wordFile.blob.size)
    }
  }
  return 'Unknown size'
}

const formatSize = (bytes) => {
  if (!bytes || isNaN(bytes)) return 'Unknown size'
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

</script>

<template>
  <div class="result-container fade-in">
    <div class="result-card">
      <div class="success-icon">✨</div>
      <h2>Conversion Complete!</h2>
      <p>Your document is ready for download.</p>
      
      <div class="file-preview">
        <div class="doc-icon">W</div>
        <div class="file-details">
          <span class="name">{{ fileName }}</span>
          <span class="size">{{ getDisplaySize() }}</span>
        </div>
      </div>
      
      <div class="actions">
        <PrimaryButton 
          text="Download Word File" 
          @click="$emit('download')"
        />
        <button class="reset-btn" @click="$emit('reset')">Convert another file</button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.result-container {
  padding: 2rem;
  background: white;
  border-radius: var(--radius-lg);
  border: 1px solid var(--border-color);
  text-align: center;
}

.success-icon {
  font-size: 3rem;
  margin-bottom: 1rem;
}

h2 {
  margin-bottom: 0.5rem;
}

p {
  color: var(--text-muted);
  margin-bottom: 2rem;
}

.file-preview {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  background: var(--bg-main);
  border-radius: var(--radius-md);
  margin-bottom: 2rem;
  text-align: left;
}

.doc-icon {
  width: 48px;
  height: 48px;
  background: #2b579a;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  font-weight: 800;
  font-size: 1.5rem;
}

.file-details {
  display: flex;
  flex-direction: column;
}

.name {
  font-weight: 600;
  color: var(--text-main);
  word-break: break-all;
}

.size {
  font-size: 0.75rem;
  color: var(--text-muted);
}

.actions {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.reset-btn {
  font-size: 0.875rem;
  color: var(--text-muted);
  font-weight: 500;
}

.reset-btn:hover {
  color: var(--primary);
}
</style>
