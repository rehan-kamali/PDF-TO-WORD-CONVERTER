<script setup>
import { watch } from 'vue'

const props = defineProps({
  progress: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    default: 'Converting...'
  },
  isVisible: {
    type: Boolean,
    default: true
  }
})

const emit = defineEmits(['conversion-complete'])

watch(() => props.progress, (newVal) => {
  if (newVal === 100) {
    setTimeout(() => emit('conversion-complete'), 500)
  }
})
</script>

<template>
  <div v-if="isVisible" class="progress-overlay glass-card">
    <div class="progress-card">
      <div class="status-header">
        <h3>{{ status }}</h3>
        <span class="percentage">{{ Math.round(progress) }}%</span>
      </div>
      
      <div class="progress-track">
        <div class="progress-fill" :style="{ width: progress + '%' }">
          <div class="glow"></div>
        </div>
      </div>
      
      <div class="status-steps">
        <div class="step" :class="{ active: progress >= 20 }">Reading PDF</div>
        <div class="step" :class="{ active: progress >= 50 }">Analyzing Layout</div>
        <div class="step" :class="{ active: progress >= 80 }">Generating Word</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.progress-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10;
  border-radius: var(--radius-lg);
}

.progress-card {
  width: 100%;
  max-width: 400px;
  padding: 2rem;
}

.status-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  margin-bottom: 1rem;
}

.status-header h3 {
  font-size: 1.125rem;
  color: var(--text-main);
}

.percentage {
  font-weight: 700;
  color: var(--primary);
  font-size: 1.25rem;
}

.progress-track {
  height: 12px;
  background: #f1f5f9;
  border-radius: 6px;
  overflow: hidden;
  margin-bottom: 1.5rem;
  box-shadow: inset 0 2px 4px rgba(0,0,0,0.05);
}

.progress-fill {
  height: 100%;
  background: var(--primary);
  border-radius: 6px;
  transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;
}

.glow {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 30px;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
  animation: shine 1.5s infinite;
}

@keyframes shine {
  from { transform: translateX(-100%); }
  to { transform: translateX(100%); }
}

.status-steps {
  display: flex;
  justify-content: space-between;
}

.step {
  font-size: 0.75rem;
  color: var(--text-muted);
  font-weight: 500;
  opacity: 0.5;
  transition: var(--transition);
}

.step.active {
  color: var(--success);
  opacity: 1;
}
</style>
