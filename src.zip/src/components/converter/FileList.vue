<script setup>
defineProps({
  files: {
    type: Array,
    default: () => []
  },
  maxItems: {
    type: Number,
    default: 5
  }
})

const formatSize = (bytes) => {
  if (!bytes) return 'N/A'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}
</script>

<template>
  <div class="file-list-card">
    <div class="card-header">
      <h3>Recent Conversions</h3>
      <span class="count">{{ files.length }}</span>
    </div>

    <div v-if="files.length === 0" class="empty-state">
      No recent conversions yet.
    </div>

    <ul v-else class="file-list">
      <li v-for="(file, index) in files.slice(0, maxItems)" :key="index" class="file-item">
        <div class="file-info">
          <span class="file-name">{{ file.name }}</span>
          <span class="file-meta">{{ formatSize(file.size) }} • {{ new Date(file.date).toLocaleTimeString() }}</span>
        </div>
        <button class="download-small" @click="$emit('download', file)" title="Download again">
          📥
        </button>
      </li>
    </ul>
  </div>
</template>

<style scoped>
.file-list-card {
  background: white;
  border-radius: var(--radius-lg);
  border: 1px solid var(--border-color);
  overflow: hidden;
}

.card-header {
  padding: 1rem 1.5rem;
  border-bottom: 1px solid var(--border-color);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-header h3 {
  font-size: 1rem;
  color: var(--text-main);
}

.count {
  font-size: 0.75rem;
  background: var(--primary-light);
  color: var(--primary);
  padding: 0.125rem 0.5rem;
  border-radius: 12px;
  font-weight: 700;
}

.empty-state {
  padding: 2rem;
  text-align: center;
  color: var(--text-muted);
  font-size: 0.875rem;
}

.file-list {
  list-style: none;
}

.file-item {
  padding: 1rem 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid var(--border-color);
  transition: var(--transition);
}

.file-item:last-child {
  border-bottom: none;
}

.file-item:hover {
  background: var(--bg-main);
}

.file-info {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.file-name {
  font-size: 0.875rem;
  font-weight: 600;
  color: var(--text-main);
}

.file-meta {
  font-size: 0.75rem;
  color: var(--text-muted);
}

.download-small {
  background: transparent;
  padding: 0.5rem;
  border-radius: var(--radius-sm);
  font-size: 1.25rem;
}

.download-small:hover {
  background: var(--primary-light);
}
</style>
