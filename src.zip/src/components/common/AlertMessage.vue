<script setup>
defineProps({
  type: {
    type: String,
    default: 'info' // info, success, warning, error
  },
  message: {
    type: String,
    required: true
  },
  dismissible: {
    type: Boolean,
    default: false
  }
})

defineEmits(['dismiss'])
</script>

<template>
  <div class="alert" :class="type" role="alert">
    <div class="alert-content">
      <span class="icon">
        <template v-if="type === 'success'">✅</template>
        <template v-else-if="type === 'error'">❌</template>
        <template v-else-if="type === 'warning'">⚠️</template>
        <template v-else>ℹ️</template>
      </span>
      <p class="message">{{ message }}</p>
    </div>
    <button v-if="dismissible" class="close-btn" @click="$emit('dismiss')" aria-label="Dismiss">
      ✕
    </button>
  </div>
</template>

<style scoped>
.alert {
  padding: 1rem;
  border-radius: var(--radius-md);
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 1rem;
  margin-bottom: 1.5rem;
  animation: slideIn 0.3s ease-out;
}

.alert-content {
  display: flex;
  gap: 0.75rem;
}

.icon {
  font-size: 1.25rem;
  flex-shrink: 0;
}

.message {
  font-size: 0.875rem;
  font-weight: 500;
  margin: 0;
}

.success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
.error { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
.warning { background: #fffbeb; color: #92400e; border: 1px solid #fef3c7; }
.info { background: #eff6ff; color: #1e40af; border: 1px solid #bfdbfe; }

.close-btn {
  background: transparent;
  padding: 0.25rem;
  font-size: 1rem;
  opacity: 0.6;
}

.close-btn:hover {
  opacity: 1;
}

@keyframes slideIn {
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
