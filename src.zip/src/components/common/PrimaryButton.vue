<script setup>
defineProps({
  text: {
    type: String,
    required: true
  },
  type: {
    type: String,
    default: 'button'
  },
  variant: {
    type: String,
    default: 'primary' // primary, secondary, outline, ghost
  },
  disabled: {
    type: Boolean,
    default: false
  },
  loading: {
    type: Boolean,
    default: false
  }
})

defineEmits(['click'])
</script>

<template>
  <button 
    :type="type"
    class="btn"
    :class="[variant, { disabled, loading }]"
    :disabled="disabled || loading"
    @click="$emit('click', $event)"
  >
    <span v-if="loading" class="loader"></span>
    <span :style="{ opacity: loading ? 0 : 1 }">{{ text }}</span>
  </button>
</template>

<style scoped>
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  font-weight: 600;
  border-radius: var(--radius-md);
  transition: var(--transition);
  position: relative;
  min-height: 48px;
  gap: 0.5rem;
}

/* Variants */
.primary {
  background: var(--primary);
  color: white;
}
.primary:hover:not(:disabled) {
  background: var(--primary-hover);
  transform: translateY(-1px);
  box-shadow: var(--shadow-md);
}

.secondary {
  background: var(--primary-light);
  color: var(--primary);
}
.secondary:hover:not(:disabled) {
  background: #dbeafe;
}

.outline {
  background: transparent;
  border: 1px solid var(--border-color);
  color: var(--text-main);
}
.outline:hover:not(:disabled) {
  border-color: var(--primary);
  color: var(--primary);
}

/* States */
.disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.loader {
  width: 20px;
  height: 20px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: white;
  animation: spin 0.8s linear infinite;
  position: absolute;
}

.secondary .loader {
  border-top-color: var(--primary);
  border-color: rgba(37, 99, 235, 0.2);
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
</style>
