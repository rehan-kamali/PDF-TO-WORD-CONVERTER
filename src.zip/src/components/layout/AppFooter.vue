<template>
  <footer class="app-footer">
    <div class="container footer-content">
      <div class="copyright">
        &copy; {{ new Date().getFullYear() }} PDF Flow Converter. All rights reserved.
      </div>
      <div class="version">
        Version 1.0.0
      </div>
    </div>
  </footer>
</template>

<style scoped>
.app-footer {
  padding: 1.5rem 0;
  background: var(--bg-card);
  border-top: 1px solid var(--border-color);
  color: var(--text-muted);
  font-size: 0.875rem;
}

.footer-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

@media (max-width: 640px) {
  .footer-content {
    flex-direction: column;
    gap: 0.5rem;
    text-align: center;
  }
}
</style>
