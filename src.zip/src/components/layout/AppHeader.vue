<script setup>
import { ref } from 'vue'
import { RouterLink, useRoute } from 'vue-router'

const route = useRoute()
const isMenuOpen = ref(false)

const navLinks = [
  { name: 'Home', path: '/' },
  { name: 'Converter', path: '/converter' },
  { name: 'About', path: '/about' },
  { name: 'Help', path: '/help' }
]

const toggleMenu = () => {
  isMenuOpen.value = !isMenuOpen.value
}
</script>

<template>
  <header class="app-header">
    <div class="container header-content">
      <RouterLink to="/" class="brand">
        <div class="logo-icon">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7 18H17V16H7V18ZM7 14H17V12H7V14ZM7 10H11V8H7V10ZM14 2H6C4.89 2 4 2.9 4 4V20C4 21.1 4.89 22 6 22H18C19.11 22 20 21.1 20 20V8L14 2ZM18 20H6V4H13V9H18V20Z" fill="currentColor"/>
          </svg>
        </div>
        <span class="logo-text">PDF<span>Flow</span></span>
      </RouterLink>

      <nav class="desktop-nav">
        <RouterLink 
          v-for="link in navLinks" 
          :key="link.path" 
          :to="link.path"
          class="nav-link"
          :class="{ active: route.path === link.path }"
        >
          {{ link.name }}
        </RouterLink>
      </nav>

      <button class="mobile-toggle" @click="toggleMenu" aria-label="Toggle menu">
        <span :class="{ open: isMenuOpen }"></span>
      </button>
    </div>

    <!-- Mobile Menu -->
    <transition name="slide">
      <div v-show="isMenuOpen" class="mobile-menu">
        <RouterLink 
          v-for="link in navLinks" 
          :key="link.path" 
          :to="link.path"
          class="mobile-link"
          @click="isMenuOpen = false"
        >
          {{ link.name }}
        </RouterLink>
      </div>
    </transition>
  </header>
</template>

<style scoped>
.app-header {
  height: 70px;
  background: var(--bg-card);
  border-bottom: 1px solid var(--border-color);
  position: sticky;
  top: 0;
  z-index: 100;
  display: flex;
  align-items: center;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
}

.brand {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--text-main);
}

.logo-icon {
  width: 32px;
  height: 32px;
  color: var(--primary);
}

.logo-text span {
  color: var(--primary);
}

.desktop-nav {
  display: flex;
  gap: 2rem;
}

.nav-link {
  font-weight: 500;
  color: var(--text-muted);
  position: relative;
  padding: 0.5rem 0;
}

.nav-link:hover, .nav-link.active {
  color: var(--primary);
}

.nav-link.active::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 2px;
  background: var(--primary);
  border-radius: 2px;
}

.mobile-toggle {
  display: none;
  width: 30px;
  height: 20px;
  position: relative;
}

.mobile-toggle span, .mobile-toggle span::before, .mobile-toggle span::after {
  content: '';
  position: absolute;
  width: 100%;
  height: 2px;
  background: var(--text-main);
  transition: var(--transition);
}

.mobile-toggle span { top: 9px; }
.mobile-toggle span::before { top: -8px; left: 0; }
.mobile-toggle span::after { bottom: -8px; left: 0; }

.mobile-toggle span.open { background: transparent; }
.mobile-toggle span.open::before { transform: rotate(45deg); top: 0; }
.mobile-toggle span.open::after { transform: rotate(-45deg); bottom: 0; }

@media (max-width: 768px) {
  .desktop-nav { display: none; }
  .mobile-toggle { display: block; }
}

.mobile-menu {
  position: absolute;
  top: 70px;
  left: 0;
  width: 100%;
  background: var(--bg-card);
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  box-shadow: var(--shadow-lg);
  border-top: 1px solid var(--border-color);
}

.mobile-link {
  padding: 1rem;
  font-weight: 500;
  border-radius: var(--radius-md);
}

.mobile-link:hover {
  background: var(--primary-light);
  color: var(--primary);
}

.slide-enter-active, .slide-leave-active {
  transition: transform 0.3s ease, opacity 0.3s ease;
}

.slide-enter-from, .slide-leave-to {
  transform: translateY(-20px);
  opacity: 0;
}
</style>
