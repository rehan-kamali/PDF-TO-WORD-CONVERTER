<template>
  <aside class="app-sidebar">
    <div class="sidebar-section">
      <h3>Quick Actions</h3>
      <div class="actions-list">
        <RouterLink to="/converter" class="action-item">
          <span class="icon">📄</span>
          New Conversion
        </RouterLink>
        <RouterLink to="/help" class="action-item">
          <span class="icon">❓</span>
          How it works
        </RouterLink>
      </div>
    </div>

    <div class="sidebar-section">
      <h3>Pro Tips</h3>
      <ul class="tips-list">
        <li>Make sure PDFs are not password protected.</li>
        <li>Large files (up to 10MB) may take longer.</li>
        <li>Images in PDF are preserved in Word.</li>
      </ul>
    </div>

    <div class="promo-card glass-card">
      <h4>Go Premium</h4>
      <p>Unlock batch processing and cloud storage.</p>
      <button class="upgrade-btn">Upgrade Now</button>
    </div>
  </aside>
</template>

<style scoped>
.app-sidebar {
  width: 280px;
  padding: 2rem 1.5rem;
  border-right: 1px solid var(--border-color);
  background: white;
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
}

.sidebar-section h3 {
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text-muted);
  margin-bottom: 1rem;
}

.actions-list {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.action-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem;
  border-radius: var(--radius-md);
  color: var(--text-main);
  font-weight: 500;
}

.action-item:hover {
  background: var(--primary-light);
  color: var(--primary);
}

.tips-list {
  list-style: none;
  font-size: 0.875rem;
  color: var(--text-muted);
}

.tips-list li {
  margin-bottom: 0.75rem;
  display: flex;
  gap: 0.5rem;
}

.tips-list li::before {
  content: '•';
  color: var(--primary);
  font-weight: bold;
}

.promo-card {
  margin-top: auto;
  padding: 1.25rem;
  border-radius: var(--radius-lg);
  border: 1px solid var(--primary-light);
  background: linear-gradient(135deg, #eff6ff 0%, #ffffff 100%);
}

.promo-card h4 {
  font-size: 1rem;
  color: var(--primary);
  margin-bottom: 0.5rem;
}

.promo-card p {
  font-size: 0.8125rem;
  color: var(--text-muted);
  margin-bottom: 1rem;
}

.upgrade-btn {
  width: 100%;
  padding: 0.625rem;
  background: var(--primary);
  color: white;
  border-radius: var(--radius-md);
  font-size: 0.875rem;
  font-weight: 600;
}

.upgrade-btn:hover {
  background: var(--primary-hover);
  transform: translateY(-1px);
}
</style>
