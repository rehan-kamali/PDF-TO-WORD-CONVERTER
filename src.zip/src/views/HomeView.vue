<script setup>
import { RouterLink } from 'vue-router'
import PrimaryButton from '@/components/common/PrimaryButton.vue'

const features = [
  {
    title: 'Privacy First',
    description: 'Your documents are processed entirely in your browser. We never upload or store your files on any server.',
    icon: '🛡️'
  },
  {
    title: 'High Fidelity',
    description: 'We strive to maintain the original layout, formatting, and images of your PDF during the conversion process.',
    icon: '💎'
  },
  {
    title: 'Completely Free',
    description: 'No subscriptions, no watermarks. Convert as many files as you need without any hidden costs.',
    icon: '✨'
  }
]
</script>

<template>
  <div class="home-view">
    <!-- Hero Section -->
    <section class="hero">
      <div class="hero-content fade-in">
        <span class="badge">SECURE CLIENT-SIDE CONVERSION</span>
        <h1>Convert PDF to Word <br><span>Seamlessly & Securely</span></h1>
        <p>The smartest way to turn your PDF documents into editable Word files. No uploads, no waiting, just results.</p>
        
        <div class="cta-group">
          <RouterLink to="/converter">
            <PrimaryButton text="Start Converting Now" />
          </RouterLink>
          <RouterLink to="/help" class="link-btn">How it works →</RouterLink>
        </div>

        <div class="stats">
          <div class="stat-item">
            <strong>100%</strong>
            <span>Secure</span>
          </div>
          <div class="stat-divider"></div>
          <div class="stat-item">
            <strong>Free</strong>
            <span>Forever</span>
          </div>
          <div class="stat-divider"></div>
          <div class="stat-item">
            <strong>0MB</strong>
            <span>Uploaded</span>
          </div>
        </div>
      </div>
      
      <div class="hero-visual fade-in">
        <div class="visual-card doc-pdf">
          <div class="icon">PDF</div>
          <div class="lines">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line short"></div>
          </div>
        </div>
        <div class="visual-arrow">→</div>
        <div class="visual-card doc-word">
          <div class="icon">DOCX</div>
          <div class="lines">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line short"></div>
          </div>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="features">
      <div class="section-title">
        <h2>Why choose PDF Flow?</h2>
        <p>We built the converter we always wanted to use.</p>
      </div>

      <div class="features-grid">
        <div v-for="feature in features" :key="feature.title" class="feature-card glass-card">
          <div class="feature-icon">{{ feature.icon }}</div>
          <h3>{{ feature.title }}</h3>
          <p>{{ feature.description }}</p>
        </div>
      </div>
    </section>

    <!-- Content Section -->
    <section class="trust">
      <div class="trust-content">
        <h2>Your Privacy is Our Priority</h2>
        <p>Unlike other online converters, PDF Flow works entirely within your web browser. Using advanced client-side technologies like WebAssembly and JavaScript, your files never leave your computer. This makes it the perfect choice for sensitive legal or financial documents.</p>
      </div>
    </section>
  </div>
</template>

<style scoped>
.home-view {
  padding-bottom: 4rem;
}

/* Hero */
.hero {
  display: grid;
  grid-template-columns: 1.2fr 0.8fr;
  gap: 4rem;
  align-items: center;
  padding: 4rem 0;
  min-height: 80vh;
}

.hero-content h1 {
  font-size: 3.5rem;
  line-height: 1.1;
  font-weight: 900;
  color: var(--text-main);
  margin-bottom: 1.5rem;
}

.hero-content h1 span {
  color: var(--primary);
}

.hero-content p {
  font-size: 1.25rem;
  color: var(--text-muted);
  max-width: 600px;
  margin-bottom: 2.5rem;
}

.badge {
  display: inline-block;
  padding: 0.5rem 1rem;
  background: var(--primary-light);
  color: var(--primary);
  font-weight: 700;
  font-size: 0.75rem;
  border-radius: 20px;
  margin-bottom: 1.5rem;
  letter-spacing: 0.05em;
}

.cta-group {
  display: flex;
  align-items: center;
  gap: 2rem;
  margin-bottom: 4rem;
}

.link-btn {
  font-weight: 600;
  color: var(--text-main);
}

.link-btn:hover {
  color: var(--primary);
  transform: translateX(5px);
}

.stats {
  display: flex;
  gap: 2.5rem;
}

.stat-item {
  display: flex;
  flex-direction: column;
}

.stat-item strong {
  font-size: 1.5rem;
  color: var(--text-main);
}

.stat-item span {
  font-size: 0.875rem;
  color: var(--text-muted);
}

.stat-divider {
  width: 1px;
  background: var(--border-color);
}

/* Hero Visual */
.hero-visual {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1.5rem;
}

.visual-card {
  width: 140px;
  height: 180px;
  background: white;
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-lg);
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.doc-pdf { border-top: 5px solid #ef4444; }
.doc-word { border-top: 5px solid #2563eb; }

.visual-card .icon {
  font-weight: 900;
  font-size: 0.875rem;
  color: var(--text-muted);
}

.visual-card .lines {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.line {
  height: 6px;
  background: #f1f5f9;
  border-radius: 3px;
}

.line.short { width: 60%; }

.visual-arrow {
  font-size: 2rem;
  color: var(--primary);
  font-weight: bold;
}

/* Features */
.features {
  padding: 6rem 0;
}

.section-title {
  text-align: center;
  margin-bottom: 4rem;
}

.section-title h2 {
  font-size: 2.5rem;
  margin-bottom: 1rem;
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2rem;
}

.feature-card {
  padding: 2.5rem;
  border-radius: var(--radius-lg);
  text-align: center;
  transition: var(--transition);
}

.feature-card:hover {
  transform: translateY(-5px);
  border-color: var(--primary);
}

.feature-icon {
  font-size: 2.5rem;
  margin-bottom: 1.5rem;
}

.feature-card h3 {
  margin-bottom: 1rem;
}

.feature-card p {
  color: var(--text-muted);
  font-size: 0.9375rem;
}

/* Trust */
.trust {
  background: var(--primary);
  color: white;
  border-radius: var(--radius-lg);
  padding: 4rem;
  text-align: center;
}

.trust h2 {
  font-size: 2rem;
  margin-bottom: 1.5rem;
}

.trust p {
  max-width: 800px;
  margin: 0 auto;
  font-size: 1.125rem;
  opacity: 0.9;
  line-height: 1.6;
}

@media (max-width: 1024px) {
  .hero {
    grid-template-columns: 1fr;
    text-align: center;
    gap: 2rem;
  }
  .hero-content p, .cta-group, .stats {
    margin-left: auto;
    margin-right: auto;
    justify-content: center;
  }
  .features-grid { grid-template-columns: 1fr; }
}
</style>
