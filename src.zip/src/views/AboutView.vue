<template>
  <div class="about-view fade-in">
    <div class="container-small">
      <h1>About PDF Flow</h1>
      
      <section class="content-text">
        <p>PDF Flow was created with a simple mission: to provide a high-quality, private, and accessible PDF to Word converter for everyone. We believe that document conversion should be effortless and secure.</p>
        
        <h2>Technology Stack</h2>
        <p>This application is built using modern web technologies that allow for complex file processing without ever needing a backend server:</p>
        
        <ul class="tech-stack">
          <li><strong>Vue 3</strong> - The progressive JavaScript framework for building interfaces.</li>
          <li><strong>Vite</strong> - Next generation frontend tooling for fast development.</li>
          <li><strong>pdf-lib</strong> - A powerful library for creating and modifying PDF documents.</li>
          <li><strong>docx</strong> - A library used to generate Word documents from scratch.</li>
          <li><strong>WebAssembly</strong> - Powers high-performance file processing in the browser.</li>
        </ul>

        <h2>The Developer</h2>
        <p>Built with ❤️ by a developer who cares about privacy and open-source tools. This project is a demonstration of what modern web browsers are capable of achieving.</p>
      </section>

      <div class="contribute-card glass-card">
        <h3>Version Info</h3>
        <p>Current Version: 1.0.0 (Release Candidate)</p>
        <p>Last Updated: October 2023</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.about-view {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem 0;
}

h1 {
  font-size: 2.5rem;
  margin-bottom: 2rem;
  color: var(--text-main);
}

h2 {
  font-size: 1.5rem;
  margin-top: 3rem;
  margin-bottom: 1rem;
}

.content-text p {
  font-size: 1.125rem;
  color: var(--text-muted);
  line-height: 1.7;
  margin-bottom: 1.5rem;
}

.tech-stack {
  list-style: none;
  margin: 1.5rem 0;
}

.tech-stack li {
  padding: 0.75rem;
  background: white;
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  margin-bottom: 0.75rem;
  font-size: 1rem;
}

.tech-stack strong {
  color: var(--primary);
}

.contribute-card {
  margin-top: 4rem;
  padding: 2rem;
  border-radius: var(--radius-lg);
  text-align: center;
}

.contribute-card p {
  color: var(--text-muted);
  font-size: 0.875rem;
  margin: 0.25rem 0;
}
</style>
