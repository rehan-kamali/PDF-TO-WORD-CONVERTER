<template>
  <div class="help-view fade-in">
    <div class="container-small">
      <h1>Help & Support</h1>
      
      <section class="help-section">
        <h2>How to convert your PDF</h2>
        <div class="steps">
          <div class="step">
            <div class="step-num">1</div>
            <div class="step-content">
              <h3>Upload Your File</h3>
              <p>Drag and drop your PDF file into the converter or click "Select File" to browse your computer.</p>
            </div>
          </div>
          <div class="step">
            <div class="step-num">2</div>
            <div class="step-content">
              <h3>Wait for Processing</h3>
              <p>Our engine will automatically begin analyzing the PDF and formatting it for Word. This usually takes 5-10 seconds.</p>
            </div>
          </div>
          <div class="step">
            <div class="step-num">3</div>
            <div class="step-content">
              <h3>Download Result</h3>
              <p>Once complete, click the "Download Word File" button to save the editable document to your device.</p>
            </div>
          </div>
        </div>
      </section>

      <section class="faq">
        <h2>Frequently Asked Questions</h2>
        <div class="faq-list">
          <div class="faq-item glass-card">
            <h4>Is my data safe?</h4>
            <p>Absolutely. We use a 100% client-side conversion method. Your files are never uploaded to any server, meaning your data stays entirely on your computer.</p>
          </div>
          <div class="faq-item glass-card">
            <h4>What is the maximum file size?</h4>
            <p>Our current limit is 10MB per file to ensure smooth performance within the browser environment.</p>
          </div>
          <div class="faq-item glass-card">
            <h4>Why is my formatting slightly different?</h4>
            <p>PDF to Word conversion is complex. While we try our best to preserve layouts, some highly complex PDFs with many layers may require slight adjustments after conversion.</p>
          </div>
        </div>
      </section>

      <div class="troubleshoot">
        <h2>Troubleshooting Tips</h2>
        <ul>
          <li><strong>PDF is too large:</strong> Try compressing your PDF before uploading.</li>
          <li><strong>Password protected:</strong> We cannot convert protected PDFs. Please remove the password first.</li>
          <li><strong>Slow conversion:</strong> Close other browser tabs to free up memory for the conversion process.</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<style scoped>
.help-view {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem 0;
}

h1 {
  font-size: 2.5rem;
  margin-bottom: 3rem;
}

h2 {
  font-size: 1.5rem;
  margin-top: 3rem;
  margin-bottom: 2rem;
  color: var(--primary);
}

.steps {
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.step {
  display: flex;
  gap: 1.5rem;
  align-items: flex-start;
}

.step-num {
  width: 40px;
  height: 40px;
  background: var(--primary);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  flex-shrink: 0;
}

.step-content h3 {
  font-size: 1.25rem;
  margin-bottom: 0.5rem;
}

.step-content p {
  color: var(--text-muted);
  line-height: 1.6;
}

.faq-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.faq-item {
  padding: 1.5rem;
  border-radius: var(--radius-md);
}

.faq-item h4 {
  margin-bottom: 0.75rem;
  color: var(--text-main);
  font-size: 1.1rem;
}

.faq-item p {
  color: var(--text-muted);
  font-size: 0.9375rem;
  line-height: 1.5;
}

.troubleshoot {
  margin-top: 4rem;
  padding: 2rem;
  background: #fff;
  border: 1px solid var(--border-color);
  border-radius: var(--radius-lg);
}

.troubleshoot ul {
  list-style: none;
  margin-top: 1rem;
}

.troubleshoot li {
  margin-bottom: 1rem;
  font-size: 1rem;
}

.troubleshoot strong {
  display: block;
  color: var(--text-main);
  margin-bottom: 0.25rem;
}
</style>
