<template>
  <div class="converter-container">
    <FileUploader 
      @file-uploaded="handleFileUpload"
      :isUploading="isConverting"
    />
    
    <ConversionProgress 
      v-if="isConverting"
      :progress="conversionProgress"
      :status="statusMessage"
      @conversion-complete="handleConversionComplete"
    />
    
    <ConversionResult 
      v-if="conversionResult"
      :wordFile="conversionResult"
      :fileName="originalFileName"
      @download="downloadWordFile"
      @reset="reset"
    />
    
    <AlertMessage 
      v-if="errorMessage"
      type="error"
      :message="errorMessage"
      @dismiss="errorMessage = null"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import FileUploader from '@/components/converter/FileUploader.vue'
import ConversionProgress from '@/components/converter/ConversionProgress.vue'
import ConversionResult from '@/components/converter/ConversionResult.vue'
import AlertMessage from '@/components/common/AlertMessage.vue'
import { PDFParse } from 'pdf-parse'
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from 'docx'

const isConverting = ref(false)
const conversionProgress = ref(0)
const statusMessage = ref('')
const conversionResult = ref(null)
const originalFileName = ref('')
const errorMessage = ref(null)

async function handleFileUpload(fileData) {
  try {
    // If the fileData structure is different, handle it (sometimes it's a direct File object, sometimes it's wrapped)
    const file = fileData.file || fileData
    originalFileName.value = file.name
    
    // Start conversion
    isConverting.value = true
    conversionProgress.value = 0
    statusMessage.value = 'Reading PDF file...'
    
    // Read PDF as ArrayBuffer
    const arrayBuffer = await file.arrayBuffer()
    conversionProgress.value = 30
    statusMessage.value = 'Extracting text from PDF...'
    
    // Configure local web worker for browser parsing
    PDFParse.setWorker('/pdf.worker.mjs')

    // Extract text using pdf-parse v2
    const parser = new PDFParse({ data: new Uint8Array(arrayBuffer) })
    const pdfData = await parser.getText()
    await parser.destroy()
    
    conversionProgress.value = 60
    statusMessage.value = 'Creating Word document...'
    
    // Check if text was extracted
    if (!pdfData.text || pdfData.text.trim().length === 0) {
      throw new Error('This PDF contains no extractable text. It might be scanned or image-based.')
    }
    
    // Create Word document with actual content
    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            text: `Converted from: ${file.name}`,
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            text: `Conversion Date: ${new Date().toLocaleString()}`,
          }),
          new Paragraph({ text: '' }),
          // Split extracted text into paragraphs
          ...pdfData.text.split('\n').map(line => 
            new Paragraph({
              text: line.trim() || ' ',
            })
          ),
        ],
      }],
    })
    
    conversionProgress.value = 90
    statusMessage.value = 'Finalizing document...'
    
    // Generate Word document blob
    const blob = await Packer.toBlob(doc)
    conversionProgress.value = 100
    statusMessage.value = 'Conversion complete!'
    
    // Store result
    conversionResult.value = {
      blob: blob,
      fileName: file.name.replace('.pdf', '_converted.docx'),
      fileSize: (blob.size / 1024).toFixed(2) + ' KB'
    }
    
  } catch (error) {
    errorMessage.value = error.message || 'Conversion failed. Please try again.'
    console.error('Conversion error:', error)
  } finally {
    isConverting.value = false
  }
}

function downloadWordFile() {
  if (conversionResult.value) {
    const url = URL.createObjectURL(conversionResult.value.blob)
    const link = document.createElement('a')
    link.href = url
    link.download = conversionResult.value.fileName
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }
}

function handleConversionComplete() {
  // Auto download or show result
}

function reset() {
  conversionResult.value = null
  originalFileName.value = ''
  errorMessage.value = null
  conversionProgress.value = 0
  isConverting.value = false
}
</script>

<style scoped>
.converter-container {
  max-width: 650px;
  margin: 2rem auto;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  min-height: 400px;
  position: relative;
}
</style>

